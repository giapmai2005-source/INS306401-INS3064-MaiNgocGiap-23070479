-- =====================================
-- Employee System
-- =====================================

DROP DATABASE IF EXISTS employee_db;

CREATE DATABASE employee_db;

USE employee_db;

CREATE TABLE employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    department ENUM('Sales','IT','HR','Marketing'),
    salary DECIMAL(15,2),
    hire_date DATE
);