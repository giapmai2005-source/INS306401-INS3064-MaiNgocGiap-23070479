-- =====================================
-- Event Tracker
-- =====================================

DROP DATABASE IF EXISTS event_db;

CREATE DATABASE event_db;

USE event_db;

CREATE TABLE events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_name VARCHAR(200),
    event_details JSON,
    start_time DATETIME
);